export const SHOWPRODUCTS = "SHOWPRODUCTS";
export const MYCHOICE = "MYCHOICE";
export const ADDTOCART = "ADDTOCART";