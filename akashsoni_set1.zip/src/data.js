`[
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0500"
      },
      "container_id": "7906614804713",
      "source_product_id": "7906614804713",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465529"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730470437097",
          "title": "Guaranteed",
          "sku": "_1",
          "quantity": 0,
          "price": 36,
          "barcode": "N/A",
          "main_image": "",
          "status": "Not Listed",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730470469865",
          "title": "Guaranteed",
          "sku": "_2",
          "quantity": "6",
          "price": 36,
          "barcode": "N/A",
          "main_image": "",
          "status": "Not Listed",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730470502633",
          "title": "Guaranteed",
          "sku": "_3",
          "quantity": "0",
          "price": 36,
          "barcode": "N/A",
          "main_image": "",
          "status": "Not Listed",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730470535401",
          "title": "Guaranteed",
          "sku": "_4",
          "quantity": "0",
          "price": 36,
          "barcode": "N/A",
          "main_image": "",
          "status": "Not Listed",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730470568169",
          "title": "Guaranteed",
          "sku": "_5",
          "quantity": "0",
          "price": 36,
          "barcode": "N/A",
          "main_image": "",
          "status": "Not Listed",
          "target_marketplace": "amazon"
        },
        {
          "target_marketplace": "amazon",
          "shop_id": "530",
          "source_product_id": "7906614804713",
          "title": "Guaranteed4796-source-3",
          "sku": "7906614804713",
          "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/guaranteed_navy.jpg?v=1664264375"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/guaranteed_navy.jpg?v=1664264375",
      "product_type": "Womens",
      "tags": "Shirts",
      "target_product_id": null,
      "title": "Guaranteed4796-source-3",
      "type": "variation",
      "updated_at": 1665559149,
      "variant_attributes": [
        "Color",
        "Size"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0501"
      },
      "container_id": "7906615787753",
      "source_product_id": "7906615787753",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465530"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730472829161",
          "title": "Cydney Plaid",
          "sku": "_103",
          "quantity": "1",
          "price": 98,
          "barcode": "N/A",
          "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/CydneyPlaid_Longsleeve_e72db08c-cd32-41eb-8251-d826cf0fc299.jpg?v=1664264412",
          "status": "Not Listed",
          "target_marketplace": "amazon",
          "error": {
            "product": [
              "Product syncing is disabled  from default setting."
            ]
          }
        },
        {
          "shop_id": "530",
          "source_product_id": "43730472861929",
          "title": "Cydney Plaid",
          "sku": "_104",
          "quantity": "0",
          "price": 98,
          "barcode": "N/A",
          "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/CydneyPlaid_Longsleeve_e72db08c-cd32-41eb-8251-d826cf0fc299.jpg?v=1664264412",
          "status": "Not Listed",
          "target_marketplace": "amazon",
          "error": {
            "product": [
              "Product syncing is disabled  from default setting."
            ]
          }
        },
        {
          "shop_id": "530",
          "source_product_id": "43730472927465",
          "title": "Cydney Plaid",
          "sku": "_105",
          "quantity": "0",
          "price": 98,
          "barcode": "N/A",
          "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/CydneyPlaid_Longsleeve_e72db08c-cd32-41eb-8251-d826cf0fc299.jpg?v=1664264412",
          "status": "Not Listed",
          "target_marketplace": "amazon",
          "error": {
            "product": [
              "Product syncing is disabled  from default setting."
            ]
          }
        },
        {
          "shop_id": "530",
          "source_product_id": "43730472960233",
          "title": "Cydney Plaid",
          "sku": "_106",
          "quantity": "0",
          "price": 98,
          "barcode": "N/A",
          "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/CydneyPlaid_Longsleeve_e72db08c-cd32-41eb-8251-d826cf0fc299.jpg?v=1664264412",
          "status": "Not Listed",
          "target_marketplace": "amazon",
          "error": {
            "product": [
              "Product syncing is disabled  from default setting."
            ]
          }
        },
        {
          "shop_id": "530",
          "source_product_id": "43730472993001",
          "title": "Cydney Plaid",
          "sku": "_107",
          "quantity": "1",
          "price": 98,
          "barcode": "N/A",
          "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/CydneyPlaid_Longsleeve_e72db08c-cd32-41eb-8251-d826cf0fc299.jpg?v=1664264412",
          "status": "Not Listed",
          "target_marketplace": "amazon",
          "error": {
            "product": [
              "Product syncing is disabled  from default setting."
            ]
          }
        },
        {
          "target_marketplace": "amazon",
          "source_product_id": "7906615787753",
          "shop_id": "530",
          "error": {
            "product": [
              "Product syncing is disabled  from default setting."
            ]
          },
          "sku": "7906615787753",
          "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/CydneyPlaid_Longsleeve_e72db08c-cd32-41eb-8251-d826cf0fc299.jpg?v=1664264412"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/CydneyPlaid_Longsleeve_e72db08c-cd32-41eb-8251-d826cf0fc299.jpg?v=1664264412",
      "product_type": "Womens",
      "tags": "Shirts",
      "target_product_id": {
        "$undefined": true
      },
      "title": {
        "$undefined": true
      },
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106891"
        }
      },
      "variant_attributes": [
        "Size"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0505"
      },
      "container_id": "7906613788905",
      "source_product_id": "7906613788905",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465530"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730468700393",
          "title": "Lodge",
          "sku": "33WSLWHV1",
          "quantity": 1,
          "price": 36,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730468733161",
          "title": "Lodge",
          "sku": "33WSLWHV2",
          "quantity": 1,
          "price": 36,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730468765929",
          "title": "Lodge",
          "sku": "33WSLWHV3",
          "quantity": 1,
          "price": 36,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730468798697",
          "title": "Lodge",
          "sku": "33WSLWHV4",
          "quantity": 1,
          "price": 36,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730468831465",
          "title": "Lodge",
          "sku": "33WSLWHV5",
          "quantity": 1,
          "price": 36,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/lodge_women_white2_df6cafb7-1756-4991-8f1c-e074ecf4a5f2.jpg?v=1664264347",
      "product_type": "Womens",
      "tags": "Shirts",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Lodge",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106891"
        }
      },
      "variant_attributes": [
        "Color",
        "Size"
      ],
      "profile": {
        "profile_id": {
          "$oid": "634566cdd9f8b7555f670017"
        },
        "profile_name": "Testing",
        "type": "manual"
      }
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0507"
      },
      "container_id": "7906613952745",
      "source_product_id": "7906613952745",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "Bush Smarts",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465530"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730468962537",
          "title": "Mud Scrub Soap",
          "sku": "_115",
          "quantity": 0,
          "price": 15,
          "barcode": "N/A",
          "main_image": "",
          "status": "Not Listed",
          "target_marketplace": "amazon"
        },
        {
          "target_marketplace": "amazon",
          "shop_id": "530",
          "source_product_id": "7906613952745",
          "sku": "7906613952745"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/soap.jpg?v=1664264351",
      "product_type": "Home",
      "tags": "",
      "target_product_id": {
        "$undefined": true
      },
      "title": {
        "$undefined": true
      },
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106892"
        }
      },
      "variant_attributes": [
        "Title"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac050a"
      },
      "container_id": "7906616115433",
      "source_product_id": "7906616115433",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "Snow Peak",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465530"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730474205417",
          "title": "Mola Headlamp",
          "sku": "ES-060OL",
          "quantity": 1,
          "price": 45,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/snowpeak_headlamp_458e50f4-a354-423e-ad48-a83c47878792.jpg?v=1664264424",
      "product_type": "Outdoor",
      "tags": "",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Mola Headlamp",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106892"
        }
      },
      "variant_attributes": [
        "Title"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac050d"
      },
      "container_id": "7906613625065",
      "source_product_id": "43730468372713",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "Ursa Major",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465530"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730468372713",
          "title": "The Scout Skincare Kit",
          "sku": "43730468372713",
          "quantity": 1,
          "price": 36,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/skin-care_c18143d5-6378-46aa-b0d7-526aee3bc776.jpg?v=1664264341",
      "product_type": "Accessories",
      "tags": "",
      "target_product_id": {
        "$undefined": true
      },
      "title": "The Scout Skincare Kit",
      "type": "simple",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106892"
        }
      },
      "variant_attributes": []
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0510"
      },
      "container_id": "7906616312041",
      "source_product_id": "7906616312041",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465530"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730474402025",
          "title": "The Field Report Vol. 2",
          "sku": "FIELDREPORT2",
          "quantity": 59,
          "price": 0,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/fieldreport_vol2_front_437c4459-042c-4b07-8018-f092a5eb83ac.jpg?v=1664264429",
      "product_type": "Home",
      "tags": "",
      "target_product_id": {
        "$undefined": true
      },
      "title": "The Field Report Vol. 2",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106887"
        }
      },
      "variant_attributes": [
        "Title"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0513"
      },
      "container_id": "7906614575337",
      "source_product_id": "7906614575337",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465530"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730469945577",
          "title": "Harriet Chambray",
          "sku": "43WCHBL1",
          "quantity": 0,
          "price": 98,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730469978345",
          "title": "Harriet Chambray",
          "sku": "43WCHBL2",
          "quantity": 0,
          "price": 98,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730470011113",
          "title": "Harriet Chambray",
          "sku": "43WCHBL3",
          "quantity": 0,
          "price": 98,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730470076649",
          "title": "Harriet Chambray",
          "sku": "43WCHBL4",
          "quantity": 0,
          "price": 98,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730470109417",
          "title": "Harriet Chambray",
          "sku": "43WCHBL5",
          "quantity": 0,
          "price": 98,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/HarrietChambray_Longsleeves_25493de2-c72b-49a0-b319-d9d4117fae8e.jpg?v=1664264367",
      "product_type": "Womens",
      "tags": "Shirts",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Harriet Chambray",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106887"
        }
      },
      "variant_attributes": [
        "Color",
        "Size"
      ],
      "profile": {
        "profile_id": {
          "$oid": "634566cdd9f8b7555f670017"
        },
        "profile_name": "Testing",
        "type": "manual"
      }
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0516"
      },
      "container_id": "7906615427305",
      "source_product_id": "7906615427305",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465531"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730472075497",
          "title": "Duckworth Woolfill Jacket",
          "sku": "FORAKER-CA2",
          "quantity": 7,
          "price": 188,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730472108265",
          "title": "Duckworth Woolfill Jacket",
          "sku": "FORAKER-CA3",
          "quantity": 13,
          "price": 188,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730472141033",
          "title": "Duckworth Woolfill Jacket",
          "sku": "FORAKER-CA4",
          "quantity": 11,
          "price": 188,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730472173801",
          "title": "Duckworth Woolfill Jacket",
          "sku": "FORAKER-CA5",
          "quantity": 6,
          "price": 188,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730472206569",
          "title": "Duckworth Woolfill Jacket",
          "sku": "FORAKER-NB2",
          "quantity": 7,
          "price": 188,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730472272105",
          "title": "Duckworth Woolfill Jacket",
          "sku": "FORAKER-NB3",
          "quantity": 15,
          "price": 188,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730472304873",
          "title": "Duckworth Woolfill Jacket",
          "sku": "FORAKER-NB4",
          "quantity": 7,
          "price": 188,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730472337641",
          "title": "Duckworth Woolfill Jacket",
          "sku": "FORAKER-NB5",
          "quantity": 0,
          "price": 188,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/woolfill-jacket_6c39ae23-c0c8-4821-85f4-4b5d64333c62.jpg?v=1664264395",
      "product_type": "Mens",
      "tags": "Jackets",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Duckworth Woolfill Jacket",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106887"
        }
      },
      "variant_attributes": [
        "Color",
        "Size"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac051a"
      },
      "container_id": "7906615918825",
      "source_product_id": "7906615918825",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "Red Wing",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465531"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730473287913",
          "title": "Red Wing Iron Ranger Boot",
          "sku": "RW8111-7",
          "quantity": 1,
          "price": 310,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730473320681",
          "title": "Red Wing Iron Ranger Boot",
          "sku": "RW8111-7.5",
          "quantity": 1,
          "price": 310,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730473353449",
          "title": "Red Wing Iron Ranger Boot",
          "sku": "RW8111-8",
          "quantity": 1,
          "price": 310,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730473386217",
          "title": "Red Wing Iron Ranger Boot",
          "sku": "RW8111-8.5",
          "quantity": 0,
          "price": 310,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730473418985",
          "title": "Red Wing Iron Ranger Boot",
          "sku": "RW8111-9",
          "quantity": 1,
          "price": 310,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730473451753",
          "title": "Red Wing Iron Ranger Boot",
          "sku": "RW8111-9-5",
          "quantity": 0,
          "price": 310,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730473484521",
          "title": "Red Wing Iron Ranger Boot",
          "sku": "RW8111-10",
          "quantity": 0,
          "price": 310,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730473517289",
          "title": "Red Wing Iron Ranger Boot",
          "sku": "RW8111-10-5",
          "quantity": 0,
          "price": 310,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730473550057",
          "title": "Red Wing Iron Ranger Boot",
          "sku": "RW8111-11",
          "quantity": 1,
          "price": 310,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730473582825",
          "title": "Red Wing Iron Ranger Boot",
          "sku": "RW8111-11-5",
          "quantity": 0,
          "price": 310,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730473615593",
          "title": "Red Wing Iron Ranger Boot",
          "sku": "RW8111-12",
          "quantity": 0,
          "price": 310,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/boot.jpg?v=1664264416",
      "product_type": "Mens",
      "tags": "Footwear",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Red Wing Iron Ranger Boot",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106888"
        }
      },
      "variant_attributes": [
        "Size"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac051e"
      },
      "container_id": "7906615034089",
      "source_product_id": "7906615034089",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465531"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730471026921",
          "title": "5 Panel Camp Cap",
          "sku": "4255",
          "quantity": 2,
          "price": 48,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730471059689",
          "title": "5 Panel Camp Cap",
          "sku": "4255OR",
          "quantity": 26,
          "price": 48,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730471092457",
          "title": "5 Panel Camp Cap",
          "sku": "4255GY",
          "quantity": 9,
          "price": 48,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730471125225",
          "title": "5 Panel Camp Cap",
          "sku": "4256",
          "quantity": 9,
          "price": 48,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/5-panel-hat_4ee20a27-8d5a-490e-a2fc-1f9c3beb7bf5.jpg?v=1664264381",
      "product_type": "Accessories",
      "tags": "Accessories",
      "target_product_id": {
        "$undefined": true
      },
      "title": "5 Panel Camp Cap",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106888"
        }
      },
      "variant_attributes": [
        "Color"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0522"
      },
      "container_id": "7906616508649",
      "source_product_id": "7906616508649",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465531"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730474664169",
          "title": "Hudderton Backpack",
          "sku": "4141",
          "quantity": 8,
          "price": 98,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730474696937",
          "title": "Hudderton Backpack",
          "sku": "4138",
          "quantity": 4,
          "price": 98,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730474729705",
          "title": "Hudderton Backpack",
          "sku": "4140",
          "quantity": 3,
          "price": 98,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730474762473",
          "title": "Hudderton Backpack",
          "sku": "4139",
          "quantity": 0,
          "price": 98,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/hudderton-backpack_dc8afb13-448b-49d9-a042-5a163a97de8f.jpg?v=1664264434",
      "product_type": "Bags",
      "tags": "Bags",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Hudderton Backpack",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106888"
        }
      },
      "variant_attributes": [
        "Color"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0524"
      },
      "container_id": "7906614673641",
      "source_product_id": "7906614673641",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465531"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730470174953",
          "title": "Derby Tier Backpack",
          "sku": "4160",
          "quantity": 50,
          "price": 148,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/derbytier_nutmeg_810294de-9152-4bf7-b5e0-b88fc94a1ff8.jpg?v=1664264371",
      "product_type": "Bags",
      "tags": "",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Derby Tier Backpack",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106888"
        }
      },
      "variant_attributes": [
        "Color"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0527"
      },
      "container_id": "7906615230697",
      "source_product_id": "7906615230697",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465532"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730471551209",
          "title": "Canvas Lunch Bag",
          "sku": "4219",
          "quantity": 2,
          "price": 32,
          "barcode": "",
          "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/Lunchbag_Khaki_Front_8ae0e1f4-407d-4ac0-89e6-961b306ef351.jpg?v=1664264390",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730471583977",
          "title": "Canvas Lunch Bag",
          "sku": "4216",
          "quantity": 0,
          "price": 32,
          "barcode": "",
          "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/Lunchbag_Moss_Front_c5dfe951-8bdc-4fff-8c8a-9a87cc02736d.jpg?v=1664264390",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730471616745",
          "title": "Canvas Lunch Bag",
          "sku": "4218",
          "quantity": 1,
          "price": 32,
          "barcode": "",
          "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/Lunchbag_Nutmeg_Front_37c94fbb-6fd7-43ed-abcf-291220a69686.jpg?v=1664264390",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/Lunchbag_Khaki_Front_8ae0e1f4-407d-4ac0-89e6-961b306ef351.jpg?v=1664264390",
      "product_type": "Bags",
      "tags": "",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Canvas Lunch Bag",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106888"
        }
      },
      "variant_attributes": [
        "Color"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac052f"
      },
      "container_id": "7906615132393",
      "source_product_id": "7906615132393",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465532"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730471223529",
          "title": "Dawson Trolley",
          "sku": "4260",
          "quantity": 0,
          "price": 278,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/DawsonTrolley_Moss_Front_6cca3dc3-51d3-4205-a1e1-ed5d9a03e181.jpg?v=1664264385",
      "product_type": "Bags",
      "tags": "",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Dawson Trolley",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106889"
        }
      },
      "variant_attributes": [
        "Color"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0530"
      },
      "container_id": "7906616148201",
      "source_product_id": "43730474238185",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "Snow Peak",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465532"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730474238185",
          "title": "Double Wall Mug",
          "sku": "MG-043R",
          "quantity": 4,
          "price": 24,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/mug.jpg?v=1664264426",
      "product_type": "Outdoor",
      "tags": "",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Double Wall Mug",
      "type": "simple",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106889"
        }
      },
      "variant_attributes": []
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0538"
      },
      "container_id": "7906614345961",
      "source_product_id": "7906614345961",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465532"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730469585129",
          "title": "Gertrude Cardigan",
          "sku": "22WCDCHC1",
          "quantity": 4,
          "price": 108,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730469617897",
          "title": "Gertrude Cardigan",
          "sku": "22WCDCHC2",
          "quantity": 9,
          "price": 108,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730469650665",
          "title": "Gertrude Cardigan",
          "sku": "22WCDCHC3",
          "quantity": 0,
          "price": 108,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730469683433",
          "title": "Gertrude Cardigan",
          "sku": "22WCDCHC4",
          "quantity": 2,
          "price": 108,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730469716201",
          "title": "Gertrude Cardigan",
          "sku": "22WCDCHC5",
          "quantity": 0,
          "price": 108,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/gertrude_charcoal.jpg?v=1664264361",
      "product_type": "Womens",
      "tags": "Sweaters",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Gertrude Cardigan",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106887"
        }
      },
      "variant_attributes": [
        "Color",
        "Size"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac053d"
      },
      "container_id": "7906613690601",
      "source_product_id": "7906613690601",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465532"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730468503785",
          "title": "Ayres Chambray",
          "sku": "43MCHBL2",
          "quantity": 1,
          "price": 98,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730468536553",
          "title": "Ayres Chambray",
          "sku": "43MCHBL3",
          "quantity": 0,
          "price": 98,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730468569321",
          "title": "Ayres Chambray",
          "sku": "43MCHBL4",
          "quantity": 25,
          "price": 98,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730468602089",
          "title": "Ayres Chambray",
          "sku": "43MCHBL5",
          "quantity": 35,
          "price": 102,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/chambray_5f232530-4331-492a-872c-81c225d6bafd.jpg?v=1664264344",
      "product_type": "Mens",
      "tags": "Shirts",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Ayres Chambray",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106889"
        }
      },
      "variant_attributes": [
        "Size"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0540"
      },
      "container_id": "7906614771945",
      "source_product_id": "7906614771945",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465532"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730470273257",
          "title": "Chevron",
          "sku": "41WCVCMV1",
          "quantity": 0,
          "price": 36,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730470306025",
          "title": "Chevron",
          "sku": "41WCVCMV2",
          "quantity": 1,
          "price": 36,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730470338793",
          "title": "Chevron",
          "sku": "41WCVCMV3",
          "quantity": 0,
          "price": 36,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730470371561",
          "title": "Chevron",
          "sku": "41WCVCMV4",
          "quantity": 0,
          "price": 36,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        },
        {
          "shop_id": "530",
          "source_product_id": "43730470404329",
          "title": "Chevron",
          "sku": "41WCVCMV5",
          "quantity": 0,
          "price": 36,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/chevron_cream_542f1c3e-e0d9-4c94-aaa2-fff0d1368206.jpg?v=1664264373",
      "product_type": "Womens",
      "tags": "Shirts",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Chevron",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106889"
        }
      },
      "variant_attributes": [
        "Color",
        "Size"
      ]
    },
    {
      "_id": {
        "$oid": "633aa7f19d5fe33b91ac0544"
      },
      "container_id": "7906616377577",
      "source_product_id": "7906616377577",
      "source_shop_id": "500",
      "target_shop_id": "530",
      "user_id": "63329d7f0451c074aa0e15a8",
      "brand": "United By Blue",
      "created_at": {
        "$date": {
          "$numberLong": "1664788465532"
        }
      },
      "items": [
        {
          "shop_id": "530",
          "source_product_id": "43730474500329",
          "title": "Camp Stool",
          "sku": "STOOLNB",
          "quantity": 9,
          "price": 78,
          "barcode": "",
          "main_image": "",
          "status": "active",
          "target_marketplace": "amazon"
        }
      ],
      "main_image": "https://cdn.shopify.com/s/files/1/0664/1693/5145/products/campstool-1.jpg?v=1664264432",
      "product_type": "Outdoor",
      "tags": "",
      "target_product_id": {
        "$undefined": true
      },
      "title": "Camp Stool",
      "type": "variation",
      "updated_at": {
        "$date": {
          "$numberLong": "1665234106889"
        }
      },
      "variant_attributes": [
        "Title"
      ]
    }
  ]`